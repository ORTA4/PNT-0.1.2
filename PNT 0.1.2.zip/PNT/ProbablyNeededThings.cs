﻿using System;

namespace PNT
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Why?");
        }
    }

    public enum DataType
    {
        Bool,
        Int,
        Float,
        String,
    }
    public static class WrRd
    {
        public static void Print(string ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public static void Print(string[] ToPrint)
        {
            int i = 0;
            Console.Write(ToPrint[i]);
            i++;
            while (i < ToPrint.Length)
            {
                Console.Write(" | ");
                Console.Write(ToPrint[i]);
                i++;
            }
        }
        public static void Print(int ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public static void Print(float ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public static void Print(double ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public static void Print(bool ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public static void PrintBlank()
        {
            Console.WriteLine("");
        }
        public static void PrintBlank(int Lines)
        {
            for(int i = 0; i < Lines; i++)
            {
                Console.WriteLine("");
            }
        }
        public static string Input(string ToPrint)
        {
            Print(ToPrint);
            string Out = Console.ReadLine();
            return Out;
        }
        public static int InputAsInt(string ToPrint)
        {
            Print(ToPrint);
            int Out = int.Parse(Console.ReadLine());
            return Out;
        }
        public static float InputAsFloat(string ToPrint)
        {
            Print(ToPrint);
            float Out = float.Parse(Console.ReadLine());
            return Out;
        }
        public static double InputAsDouble(string ToPrint)
        {
            Print(ToPrint);
            double Out = double.Parse(Console.ReadLine());
            return Out;
        }
        public static bool InputAsBool(string ToPrint)
        {
            Print(ToPrint);
            bool Out = bool.Parse(Console.ReadLine());
            return Out;
        }
        public static void SetWindowSize(int Width, int Height)
        {
            Console.SetWindowSize(Width, Height);
        }
        public static void SetCursorPosition(int YPos, int XPos)
        {
            Console.SetCursorPosition(XPos + 1, YPos + 1);
        }
        public static void SetConsoleColors(ConsoleColor Foreground, ConsoleColor Background)
        {
            Console.BackgroundColor = Background;
            Console.ForegroundColor = Foreground;
        }
    }
    public static class Converter
    {
        public static string ToStr(int ToString)
        {
            return ToString.ToString();
        }
        public static string ToStr(float ToString)
        {
            return ToString.ToString();
        }
        public static string ToStr(double ToString)
        {
            return ToString.ToString();
        }
        public static string ToStr(bool ToString)
        {
            return ToString.ToString();
        }
        public static int ToInt(string ToInt)
        {
            return int.Parse(ToInt);
        }
        public static int ToInt(float ToInt)
        {
            return (int)Math.Round(ToInt);
        }
        public static int ToInt(double ToInt)
        {
            return (int)Math.Round(ToInt);
        }
        public static int ToInt(bool ToInt)
        {
            if(ToInt)
            {
                return 1;
            }
            return 0;
        }
        public static float ToFlt(string ToFloat)
        {
            return float.Parse(ToFloat);
        }
        public static float ToFlt(int ToFloat)
        {
            return ToFloat;
        }
        public static float ToFlt(double ToFloat)
        {
            return (float)ToFloat;
        }
        public static float ToFlt(bool ToFloat)
        {
            return ToInt(ToFloat);
        }
        public static double ToDbl(string ToDouble)
        {
            return double.Parse(ToDouble);
        }
        public static double ToDbl(int ToDouble)
        {
            return ToDouble;
        }
        public static double ToDbl(float ToDouble)
        {
            return ToDouble;
        }
        public static double ToDbl(bool ToDouble)
        {
            return ToInt(ToDouble);
        }
        public static bool ToBol(string ToBool)
        {
            return bool.Parse(ToBool.ToLower());
        }
        public static bool ToBol(int ToBool)
        {
            return ToBol((double)ToBool);
        }
        public static bool ToBol(float ToBool)
        {
            return ToBol((double)ToBool);
        }
        public static bool ToBol(double ToBool)
        {
            if(ToBool <= 0)
            {
                return false;
            }
            return true;
        }
        public static string[] ToStrArr(int[] ToStringArray)
        {
            string[] Out = new string[ToStringArray.Length];
            for(int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToStringArray[i].ToString();
            }
            return Out;
        }
        public static string[] ToStrArr(float[] ToStringArray)
        {
            string[] Out = new string[ToStringArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToStringArray[i].ToString();
            }
            return Out;
        }
        public static string[] ToStrArr(double[] ToStringArray)
        {
            string[] Out = new string[ToStringArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToStringArray[i].ToString();
            }
            return Out;
        }
        public static string[] ToStrArr(bool[] ToStringArray)
        {
            string[] Out = new string[ToStringArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToStringArray[i].ToString();
            }
            return Out;
        }
        public static int[] ToIntArr(string[] ToIntArray)
        {
            int[] Out = new int[ToIntArray.Length];
            for(int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToInt(ToIntArray[i]);
            }
            return Out;
        }
        public static int[] ToIntArr(float[] ToIntArray)
        {
            int[] Out = new int[ToIntArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToInt(ToIntArray[i]);
            }
            return Out;
        }
        public static int[] ToIntArr(double[] ToIntArray)
        {
            int[] Out = new int[ToIntArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToInt(ToIntArray[i]);
            }
            return Out;
        }
        public static int[] ToIntArr(bool[] ToIntArray)
        {
            int[] Out = new int[ToIntArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToInt(ToIntArray[i]);
            }
            return Out;
        }
        public static float[] ToFltArr(string[] ToFloatArray)
        {
            float[] Out = new float[ToFloatArray.Length];
            for(int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToFlt(ToFloatArray[i]);
            }
            return Out;
        }
        public static float[] ToFltArr(int[] ToFloatArray)
        {
            float[] Out = new float[ToFloatArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToFlt(ToFloatArray[i]);
            }
            return Out;
        }
        public static float[] ToFltArr(double[] ToFloatArray)
        {
            float[] Out = new float[ToFloatArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToFlt(ToFloatArray[i]);
            }
            return Out;
        }
        public static float[] ToFltArr(bool[] ToFloatArray)
        {
            float[] Out = new float[ToFloatArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToFlt(ToFloatArray[i]);
            }
            return Out;
        }
        public static double[] ToDblArr(string[] ToDoubleArray)
        {
            double[] Out = new double[ToDoubleArray.Length];
            for(int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToDbl(ToDoubleArray[i]);
            }
            return Out;
        }
        public static double[] ToDblArr(int[] ToDoubleArray)
        {
            double[] Out = new double[ToDoubleArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToDbl(ToDoubleArray[i]);
            }
            return Out;
        }
        public static double[] ToDblArr(float[] ToDoubleArray)
        {
            double[] Out = new double[ToDoubleArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToDbl(ToDoubleArray[i]);
            }
            return Out;
        }
        public static double[] ToDblArr(bool[] ToDoubleArray)
        {
            double[] Out = new double[ToDoubleArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToDbl(ToDoubleArray[i]);
            }
            return Out;
        }
        public static bool[] ToBolArr(string[] ToBoolArray)
        {
            bool[] Out = new bool[ToBoolArray.Length];
            for(int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToBol(ToBoolArray[i]);
            }
            return Out;
        }
        public static bool[] ToBolArr(int[] ToBoolArray)
        {
            bool[] Out = new bool[ToBoolArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToBol(ToBoolArray[i]);
            }
            return Out;
        }
        public static bool[] ToBolArr(float[] ToBoolArray)
        {
            bool[] Out = new bool[ToBoolArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToBol(ToBoolArray[i]);
            }
            return Out;
        }
        public static bool[] ToBolArr(double[] ToBoolArray)
        {
            bool[] Out = new bool[ToBoolArray.Length];
            for (int i = 0; i < Out.Length; i++)
            {
                Out[i] = ToBol(ToBoolArray[i]);
            }
            return Out;
        }
    }
    public static class Time
    {
        public static int Hour()
        {
            return DateTime.Now.Hour;
        }
        public static int Minute()
        {
            return DateTime.Now.Minute;
        }
        public static int Second()
        {
            return DateTime.Now.Second;
        }
        public static int Millisecond()
        {
            return DateTime.Now.Millisecond;
        }
        public static DateTime Now()
        {
            return DateTime.Now;
        }
    }
    public class UADdcy
    {
        public void Print(string ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public void Print(string[] ToPrint)
        {
            int i = 0;
            Console.Write(ToPrint[i]);
            i++;
            while (i < ToPrint.Length)
            {
                Console.Write(" | ");
                Console.Write(ToPrint[i]);
                i++;
            }
        }
        public void Print(int ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public void Print(float ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public void Print(double ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public void Print(bool ToPrint)
        {
            Console.WriteLine(ToPrint);
        }
        public void PrintBlank()
        {
            Console.WriteLine("");
        }
        public void PrintBlank(int Lines)
        {
            for (int i = 0; i < Lines; i++)
            {
                Console.WriteLine("");
            }
        }
        public string Input(string ToPrint)
        {
            Print(ToPrint);
            string Out = Console.ReadLine();
            return Out;
        }
        public int InputAsInt(string ToPrint)
        {
            Print(ToPrint);
            int Out = int.Parse(Console.ReadLine());
            return Out;
        }
        public float InputAsFloat(string ToPrint)
        {
            Print(ToPrint);
            float Out = float.Parse(Console.ReadLine());
            return Out;
        }
        public double InputAsDouble(string ToPrint)
        {
            Print(ToPrint);
            double Out = double.Parse(Console.ReadLine());
            return Out;
        }
        public bool InputAsBool(string ToPrint)
        {
            Print(ToPrint);
            bool Out = bool.Parse(Console.ReadLine());
            return Out;
        }
        public string ToStr(int ToString)
        {
            return ToString.ToString();
        }
        public string ToStr(float ToString)
        {
            return ToString.ToString();
        }
        public string ToStr(double ToString)
        {
            return ToString.ToString();
        }
        public string ToStr(bool ToString)
        {
            return ToString.ToString();
        }
        public int ToInt(string ToInt)
        {
            return int.Parse(ToInt);
        }
        public int ToInt(float ToInt)
        {
            return (int)Math.Round(ToInt);
        }
        public int ToInt(double ToInt)
        {
            return (int)Math.Round(ToInt);
        }
        public int ToInt(bool ToInt)
        {
            if (ToInt)
            {
                return 1;
            }
            return 0;
        }
        public float ToFlt(string ToFloat)
        {
            return float.Parse(ToFloat);
        }
        public float ToFlt(int ToFloat)
        {
            return ToFloat;
        }
        public float ToFlt(double ToFloat)
        {
            return (float)ToFloat;
        }
        public float ToFlt(bool ToFloat)
        {
            return ToInt(ToFloat);
        }
        public double ToDbl(string ToDouble)
        {
            return double.Parse(ToDouble);
        }
        public double ToDbl(int ToDouble)
        {
            return ToDouble;
        }
        public double ToDbl(float ToDouble)
        {
            return ToDouble;
        }
        public double ToDbl(bool ToDouble)
        {
            return ToInt(ToDouble);
        }
        public bool ToBol(string ToBool)
        {
            return bool.Parse(ToBool.ToLower());
        }
        public bool ToBol(int ToBool)
        {
            return ToBol((double)ToBool);
        }
        public bool ToBol(float ToBool)
        {
            return ToBol((double)ToBool);
        }
        public bool ToBol(double ToBool)
        {
            if (ToBool <= 0)
            {
                return false;
            }
            return true;
        }
        public void Repeat(int Times, Action action)
        {
            for(int i = 0; i < Times; i++)
            {
                action();
            }
        }
        public void EndPrm(bool AddMasage)
        {
            if(AddMasage)
            {
                PrintBlank(3);
                Print("Press any button to end programm.");
            }
            Console.ReadKey();
        }
        public void SetWindowSize(int Width, int Height)
        {
            Console.SetWindowSize(Width, Height);
        }
        public void SetCursorPosition(int YPos, int XPos)
        {
            Console.SetCursorPosition(XPos + 1, YPos + 1);
        }
        public static void SetConsoleColors(ConsoleColor Foreground, ConsoleColor Background)
        {
            Console.BackgroundColor = Background;
            Console.ForegroundColor = Foreground;
        }
    }
    public class BIFS
    {
        private DataType Type = DataType.String;
        private string Data = null;
        public void Set(bool Value)
        {
            Type = DataType.Bool;
            Data = Value.ToString();
        }
        public void Set(int Value)
        {
            Type = DataType.Int;
            Data = Value.ToString();
        }
        public void Set(float Value)
        {
            Type = DataType.Float;
            Data = Value.ToString();
        }
        public void Set(string Value)
        {
            Type = DataType.String;
            Data = Value;
        }
        public object GetValue()
        {
            if (Type == DataType.Bool)
            {
                return bool.Parse(Data);
            }
            else if(Type == DataType.Int)
            {
                return int.Parse(Data);
            }
            else if(Type == DataType.Float)
            {
                return float.Parse(Data);
            }
            else if(Type == DataType.String)
            {
                return Data;
            }
            else
            {
                Console.WriteLine("Error PNT 000: BIFS is not specified");
                return null;
            }
        }
        public bool GetValueAsBool()
        {
            if(Type == DataType.Bool)
            {
                return bool.Parse(Data);
            }
            else
            {
                Console.WriteLine("Error PNT 001: BIFS is no Bool");
                return false;
            }
        }
        public int GetValueAsInt()
        {
            if(Type == DataType.Int)
            {
                return int.Parse(Data);
            }
            else
            {
                Console.WriteLine("Error PNT 002: BIFS is no Int");
                return 0;
            }
        }
        public float GetValueAsFloat()
        {
            if(Type == DataType.Float)
            {
                return float.Parse(Data);
            }
            else
            {
                Console.WriteLine("Error PNT 003: BIFS is no Float");
                return 0.0F;
            }
        }
        public string GetValueAsString()
        {
            if(Type == DataType.String)
            {
                return Data;
            }
            else
            {
                Console.WriteLine("Error PNT 004: BIFS is no String");
                return "";
            }
        }
        public BIFS(bool Value)
        {
            Data = Value.ToString();
            Type = DataType.Bool;
        }
        public BIFS(int Value)
        {
            Data = Value.ToString();
            Type = DataType.Int;
        }
        public BIFS(float Value)
        {
            Data = Value.ToString();
            Type = DataType.Float;
        }
        public BIFS(string Value)
        {
            Data = Value;
            Type = DataType.String;
        }
        public override string ToString()
        {
            return Data;
        }
    }
    namespace Maths
    {
        public static class PNMath
        {
            public static readonly double Pi = Math.PI;
            public static readonly double e = Math.E;
            public static float Lerp(float a, float b, float Speed)
            {
                return (a - b) / Speed;
            }
            public static float Sqd(float a)
            {
                return a * a;
            }
            public static float Cubd(float a)
            {
                return a * a * a;
            }
            public static float Power(float a, int Power)
            {
                float Out = 1.0F;
                for(int i = 0; i < Power; i++)
                {
                    Out *= a;
                }
                return Out;
            }
            public static float SqRt(float a)
            {
                return (float)Math.Sqrt(a);
            }
            public static float CubRt(float a)
            {
                return (float)Math.Pow(a, 1 / 3);
            }
            public static float Root(float a, float RtPower)
            {
                return (float)Math.Pow(a, 1 / RtPower);
            }
        }
        namespace Vector
        {
            public class Vec2
            {
                public float X = 0.0F;
                public float Y = 0.0F;

                public void Set(float XVal, float YVal)
                {
                    X = XVal;
                    Y = YVal;
                }
                public void Set(Vec2 ToSet)
                {
                    X = ToSet.X;
                    Y = ToSet.Y;
                }
                public void SetZero()
                {
                    X = 0.0F;
                    Y = 0.0F;
                }
                public float GetLenght()
                {
                    return (float)Math.Sqrt(Math.Pow(X, 2) + Math.Pow(Y, 2));
                }
                public Vec2(float x, float y)
                {
                    X = x;
                    Y = y;
                }
                public static Vec2 operator +(Vec2 A, Vec2 B)
                {
                    return new Vec2(A.X + B.X, A.Y + B.Y);
                }
                public static Vec2 operator *(Vec2 A, Vec2 B)
                {
                    return new Vec2(A.X * B.X, A.Y * B.Y);
                }
                public static Vec2 operator *(Vec2 A, float B)
                {
                    return new Vec2(A.X * B, A.Y * B);
                }
                public static Vec2 operator -(Vec2 A, Vec2 B)
                {
                    return new Vec2(A.X - B.X, A.Y - B.Y);
                }
                public static Vec2 operator /(Vec2 A, Vec2 B)
                {
                    return new Vec2(A.X / B.X, A.Y / B.Y);
                }
                public static Vec2 operator /(Vec2 A, float B)
                {
                    return new Vec2(A.X / B, A.Y / B);
                }
                public override string ToString()
                {
                    return X.ToString() + " | " + Y.ToString();
                }
            }
            public class Vec3
            {
                public float X = 0.0F;
                public float Y = 0.0F;
                public float Z = 0.0F;

                public void Set(float XVal, float YVal)
                {
                    X = XVal;
                    Y = YVal;
                    Z = 0.0F;
                }
                public void Set(float XVal, float YVal, float ZVal)
                {
                    X = XVal;
                    Y = YVal;
                    Z = ZVal;
                }
                public void Set(Vec2 ToSet)
                {
                    X = ToSet.X;
                    Y = ToSet.Y;
                    Z = 0.0F;
                }
                public void Set(Vec3 ToSet)
                {
                    X = ToSet.X;
                    Y = ToSet.Y;
                    Z = ToSet.Z;
                }
                public void SetZero()
                {
                    X = 0.0F;
                    Y = 0.0F;
                    Z = 0.0F;
                }
                public float GetLenght()
                {
                    return (float)Math.Sqrt(Math.Pow(X, 2) + Math.Pow(Y, 2) + Math.Pow(Z, 2));
                }
                public Vec3(float x, float y)
                {
                    X = x;
                    Y = y;
                    Z = 0;
                }
                public Vec3(float x, float y, float z)
                {
                    X = x;
                    Y = y;
                    Z = z;
                }
                public static Vec3 operator +(Vec3 A, Vec3 B)
                {
                    return new Vec3(A.X + B.X, A.Y + B.Y, A.Z + B.Z);
                }
                public static Vec3 operator *(Vec3 A, Vec3 B)
                {
                    return new Vec3(A.X * B.X, A.Y * B.Y, A.Z * B.Z);
                }
                public static Vec3 operator *(Vec3 A, float B)
                {
                    return new Vec3(A.X * B, A.Y * B, A.Z * B);
                }
                public static Vec3 operator -(Vec3 A, Vec3 B)
                {
                    return new Vec3(A.X - B.X, A.Y - B.Y, A.Z - B.Z);
                }
                public static Vec3 operator /(Vec3 A, Vec3 B)
                {
                    return new Vec3(A.X / B.X, A.Y / B.Y, A.Z / B.Z);
                }
                public static Vec3 operator /(Vec3 A, float B)
                {
                    return new Vec3(A.X / B, A.Y / B, A.Z / B);
                }
                public override string ToString()
                {
                    return X.ToString() + " | " + Y.ToString() + " | " + Z.ToString();
                }
            }
            public class VecI
            {
                private bool IsSetUp = false;
                public float[] Values;
                public int Dimensions;
                public void SetUp(int VectorDimensions)
                {
                    if(!IsSetUp)
                    {
                        Values = new float[VectorDimensions];
                        Dimensions = VectorDimensions;
                    }
                    else
                    {
                        Console.WriteLine("Error PNT 010: VecI is already set up.");
                    }
                }
                public float GetValue(int IndexNum)
                {
                    return Values[IndexNum];
                }
                public int GetDimension()
                {
                    return Dimensions;
                }
                public float GetLenght()
                {
                    float BetweenLenght = 0;
                    for (int i = 0; i < Dimensions; i++)
                    {
                        BetweenLenght += (float)Math.Pow(Values[i], 2);
                    }
                    return (float)Math.Sqrt(BetweenLenght);
                }
                public void Add(int IndexNum, float Adder)
                {
                    Values[IndexNum] += Adder;
                }
                public void Sub(int IndexNum, float Subber)
                {
                    Values[IndexNum] -= Subber;
                }
                public void Mult(int IndexNum, float Multiplyer)
                {
                    Values[IndexNum] *= Multiplyer;
                }
                public void Mult(float Multiplyer)
                {
                    for(int i = 0; i < Dimensions; i++)
                    {
                        Values[i] *= Multiplyer;
                    }
                }
                public void Dev(int IndexNum, float Devider)
                {
                    Values[IndexNum] /= Devider;
                }
                public void Dev(float Devider)
                {
                    for (int i = 0; i < Dimensions; i++)
                    {
                        Values[i] /= Devider;
                    }
                }
                public VecI(int dimensions)
                {
                    SetUp(dimensions);
                }
                public override string ToString()
                {
                    string Out = "";
                    Out = Values[0].ToString();
                    for(int i = 1; i < Dimensions; i++)
                    {
                        Out += " | ";
                        Out += Values[i].ToString();
                    }
                    return Out;
                }
            }
        }
        namespace BitOperations
        {
            public enum OperationsRTB
            {
                And,
                Or,
                Xor,
                Nand,
                Nor,
                XNor,
            }
            public enum OperationsROB
            {
                Not,
            }
            public static class BitOperator
            {
                public static bool Operation(bool a, bool b, OperationsRTB Opr)
                {
                    if(Opr == OperationsRTB.And)
                    {
                        if(a && b)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else if(Opr == OperationsRTB.Nand)
                    {
                        if(a && b)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    else if(Opr == OperationsRTB.Nor)
                    {
                        if(!a && !b)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else if(Opr == OperationsRTB.Or)
                    {
                        if(a || b)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else if(Opr == OperationsRTB.XNor)
                    {
                        int XNorC = 0;
                        if(a)
                        {
                            XNorC++;
                        }
                        if(b)
                        {
                            XNorC++;
                        }
                        if(XNorC == 1)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    else
                    {
                        int XorC = 0;
                        if (a)
                        {
                            XorC++;
                        }
                        if (b)
                        {
                            XorC++;
                        }
                        if(XorC == 1)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                public static bool Operation(bool Value, OperationsROB Opr)
                {
                    if(Opr == OperationsROB.Not)
                    {
                        return !Value;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
    }
    namespace Random
    {
        public enum SetSeedType
        {
            Simple,
            Timebased,
            OnlyTimebased,
        }
        public class Rand
        {
            public int seed = 0;
            public void SetSeed(int Seed)
            {
                seed = Seed;
            }
            public void SetSeed(SetSeedType Type)
            {
                if(Type == SetSeedType.Simple)
                {
                    seed = GetRandom(1000000000);
                }
                else if(Type == SetSeedType.Timebased)
                {
                    seed = Math.Abs(GetRandom(500000000) + (DateTime.Now.Millisecond * DateTime.Now.Second));
                }
                else if(Type == SetSeedType.OnlyTimebased)
                {
                    seed = Math.Abs(DateTime.Now.Millisecond + (DateTime.Now.Second - DateTime.Now.Hour) * DateTime.Now.Minute);
                }
            }
            public int GetRandom(int Max)
            {
                int preeA = (int)Math.Pow(seed, 2);
                float preeB = (float)Math.Sin(seed * 2);
                return (int)Math.Abs((preeA * preeB) % Max);
            }
            public int GetRandom(int Min, int Max)
            {
                int PreeSeed = seed;
                int Out = GetRandom(Max);

                while(Out < Min)
                {
                    seed++;
                    Out = GetRandom(Max);
                }

                seed = PreeSeed;

                return Out;
            }
            public int[] GetNoise(int  Lentgh, int SmothFactor)
            {
                int[] Out = new int[Lentgh];
                int preeSeed = seed;
                int A = 0;
                int B = 0;

                Out[0] = GetRandom(1000);

                for(int i = 1; i < Lentgh; i++)
                {
                    SetSeed(SetSeedType.Timebased);
                    A = Out[i - 1] + SmothFactor;
                    B = Out[i - 1] - SmothFactor;
                    if(A > 1000)
                    {
                        A = 1000;
                    }
                    if(B < 0)
                    {
                        B = 0;
                    }
                    Out[i] = GetRandom(B, A + 1);
                }

                seed = preeSeed;

                return Out;
            }
            public Rand (int Seed)
            {
                seed = Seed;
            }
        }
    }
}